library(MKinfer)

t.test <- est.e %>% 
  select(c(e3.enojos,e3.gritos,sexo))

t.test$sexo <- ifelse(t.test$sexo == "Hombre",0,1)

t.test$e3.enojos <- as.character(t.test$e3.enojos)
t.test$e3.enojos[t.test$e3.enojos=="Nunca"] <- 0
t.test$e3.enojos[t.test$e3.enojos=="Casi nunca"] <- 1
t.test$e3.enojos[t.test$e3.enojos=="A veces"] <- 2
t.test$e3.enojos[t.test$e3.enojos=="Frecuentemente"] <- 3
t.test$e3.enojos[t.test$e3.enojos=="Casi siempre"] <- 4
t.test$e3.enojos[t.test$e3.enojos=="Siempre"] <- 5
t.test$e3.enojos <- as.numeric(t.test$e3.enojos)

t.test$e3.gritos <- as.character(t.test$e3.gritos)
t.test$e3.gritos[t.test$e3.gritos=="Nunca"] <- 0
t.test$e3.gritos[t.test$e3.gritos=="Casi nunca"] <- 1
t.test$e3.gritos[t.test$e3.gritos=="A veces"] <- 2
t.test$e3.gritos[t.test$e3.gritos=="Frecuentemente"] <- 3
t.test$e3.gritos[t.test$e3.gritos=="Casi siempre"] <- 4
t.test$e3.gritos[t.test$e3.gritos=="Siempre"] <- 5
t.test$e3.gritos <- as.numeric(t.test$e3.gritos)

boot.t.test(t.test$e3.gritos ~ t.test$sexo, alternative = c("two.sided"), mu = 0, paired = FALSE, var.equal = TRUE, conf.level = 0.95)

boot.t.test(t.test$e3.enojos ~ t.test$sexo, alternative = c("two.sided"), mu = 0, paired = FALSE, var.equal = TRUE, conf.level = 0.95)
